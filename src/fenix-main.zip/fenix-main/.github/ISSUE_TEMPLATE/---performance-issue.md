---
name: "⌛ Performance issue"
about: Create a performance issue if the app is slow or it uses too much memory, disk space, battery, or network data
title: ""
labels: "eng:performance"
assignees: ''

---

## Steps to reproduce

### Expected behavior

### Actual behavior

### Device information

* Android device: ?
* Fenix version: ?
