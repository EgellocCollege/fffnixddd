---
name: "\U0001F469\U0001F3FB‍\U0001F4BB User Story"
about: Create a user story for an epic
title: ""
labels: ''
assignees: ''

---
## User Story
- As a user, I want … so I can do … (keep it problem-centric)

## Dependencies
- List dependencies on other issues/teams etc.


### Acceptance Criteria
- I can do …  (e.g. add a bookmark)

